package com.shailly.appointmentPackage;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.time.LocalDate;

public class AppointmentManager {


    private final String APPOINTMENTS_FILE = "appointments.txt";
    private ObservableList<Appointment> appointments;

    public AppointmentManager(){
        // initialize the appointments list
        appointments = FXCollections.observableArrayList();
    }


    public ObservableList<Appointment> getAllAppointments(){
        return this.appointments;
    }


    public boolean addAppointment(Appointment appointment){
        if(isExists(appointment.getTitle())){
            // appointment with this title already exists
            return false;
        }else{
            appointments.add(appointment);
            return true;
        }
    }

    public boolean deleteAppointment(Appointment appointment){
        if(isExists(appointment.getTitle())){
            this.appointments.remove(appointment);
            return true;
        }else{
            return false;
        }
    }

    private boolean isExists(String title){
        for(Appointment appointment: appointments){
            if(appointment.getTitle().equals(title)){
                return true;
            }else{
                continue;
            }
        }
        return false;
    }


    public boolean loadAppointments(){
        try{
            FileReader reader = new FileReader(APPOINTMENTS_FILE);
            BufferedReader br = new BufferedReader(reader);
            String details ;
            while( (details = br.readLine()) != null){
                String[] partOfDetails = details.split("\t");
                String title = partOfDetails[0];
                LocalDate dateOfIssue = LocalDate.parse(partOfDetails[1]);
                LocalDate deadline = LocalDate.parse(partOfDetails[2]);
                String notes = partOfDetails[3];
                Appointment appointment = new Appointment(title,notes,deadline,dateOfIssue);
                appointments.add(appointment);
            }
            reader.close();
            br.close();
            return true;
        }catch(IOException e){
            System.out.println("Could not load the file " + APPOINTMENTS_FILE);
            return false;
        }
    }

    public boolean saveAppointments(){
        try {
            FileWriter writer = new FileWriter(APPOINTMENTS_FILE);
            BufferedWriter bw = new BufferedWriter(writer);
            for(Appointment appointment : appointments){
                String details = appointment.getTitle() + "\t" + appointment.getDateOfIssue() + "\t" +
                        appointment.getDeadline() + "\t" + appointment.getNotes();
                bw.append(details);
                bw.newLine();

                // appended four component
                // Zeroth component is title
                // First component is date of issue
                // Second component is deadline
                // Third component is notes
            }
            bw.close();
            writer.close();
            return true;
        }catch(IOException e){
            System.out.println("Could not load the file " + APPOINTMENTS_FILE);
            return false;
        }
    }
}
