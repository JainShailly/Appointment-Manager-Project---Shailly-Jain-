package com.shailly.appointmentPackage;

import java.time.LocalDate;

public class Appointment{

    private String title;
    private String notes;
    private LocalDate deadline;
    private LocalDate dateOfIssue;

    public Appointment(String title, String notes, LocalDate deadline, LocalDate dateOfIssue) {
        this.title = title;
        this.notes = notes;
        this.deadline = deadline;
        this.dateOfIssue = dateOfIssue;
    }

    @Override
    public String toString() {
        return this.title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public LocalDate getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(LocalDate dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

}
