/*
* Developed by Shailly Jain
* */

package com.shailly;

import com.shailly.appointmentPackage.Appointment;
import com.shailly.appointmentPackage.AppointmentManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;


public class Controller {

    private AppointmentManager manager ;

    @FXML
    public ListView<Appointment> listView;

    @FXML
    public Label dateOfIssueLabel, deadlineLabel,notesLabel,appointmentType,dateTimeLabel;
    @FXML
    public TextArea notesArea;
    @FXML
    public TextField searchField;
    @FXML
    public ChoiceBox<String> choiceBox;

    @FXML
    public Button newAppointmentButton, editAppointmentButton,deleteButton,searchButton;

    @FXML
    public void initialize(){

        try{
            newAppointmentButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("newAppointment.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon newAppointment.png");
        }
        try{
            editAppointmentButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("editAppointment.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon editAppointment.png");
        }
        try{
            deleteButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("deleteIcon.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon deleteIcon.png");
        }
        try{
            searchButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("search.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon search.png");
        }

        // add items to choiceBox
        choiceBox.getItems().add("Show All Appointments");
        choiceBox.getItems().add("Show Delayed Appointments");
        choiceBox.getItems().add("Show Today's Appointments");
        choiceBox.getItems().add("Show Upcoming Appointments");
        choiceBox.getSelectionModel().selectLast(); // select upcoming appointments

        manager = new AppointmentManager(); // initialize the manager object
        manager.loadAppointments(); // load the appointments save to the Hard disk if any

        //set the cursor to hand cursor
        listView.setCursor(Cursor.HAND);

        // allow only the single selection of the list
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        // get the list of all appointments saved to the memory
        ObservableList<Appointment> appointments= (ObservableList<Appointment>) manager.getAllAppointments();

        // sort appointments by deadline
        FXCollections.sort(appointments, new Comparator<Appointment>() {
            @Override
            public int compare(Appointment o1, Appointment o2) {
                return o1.getDeadline().compareTo(o2.getDeadline());
            }
        });

        // Get only Upcoming appointments
        FilteredList<Appointment> upcomingAppointments = appointments.filtered(new Predicate<Appointment>() {
            @Override
            public boolean test(Appointment appointment) {
                return appointment.getDeadline().compareTo(LocalDate.now()) >=0 ;
            }
        });

        // set the items of the list view
        listView.setItems(upcomingAppointments);

        if(upcomingAppointments.size() >0){
            // is list view is not empty, select the first item
            listView.getSelectionModel().selectFirst();
            appointmentType.setText("Upcoming Appointments");
            displayDetailsOfSelectedItem(); // display the content of the selected item
        }else{
            // mark the label as appropriate
            appointmentType.setText("No Upcoming appointments");
        }

        // set the today's date
        dateTimeLabel.setText("     " + LocalDate.now().format(
                    DateTimeFormatter.ofPattern("E, d MMM YYYY")));
    }

    @FXML
    public void handleNewAppointment(){
        // handle the event fired by the new appointment button

        Dialog<ButtonType> dialog = new Dialog<>(); // creates a dialog of ButtonType
        FXMLLoader loader = new FXMLLoader(); // to load the fxml file
        loader.setLocation(getClass().getResource("newAppointment.fxml")); // set the location of the fxml file
        try{
            dialog.getDialogPane().setContent(loader.load()); // set the content of the fxml file on the dialog
        }catch(IOException e){
            // exception
            System.out.println("Couldn't load the newAppointment.fxml file");
            return;
        }
        // file loaded successfully
        dialog.setTitle("New Appointment"); // set the title of the dialog
        // add buttons to the dialog
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        // show the dialog and the result
        Optional<ButtonType> result = dialog.showAndWait();

        if( result.isPresent() && result.get() == ButtonType.OK){
            // OK was pressed
            //  get the details from the fields
            NewAppointmentController controller = loader.getController(); // get the controller class object of fxml file
            String title = controller.getTitle(); // get the title of the appointment from field
            String notes = controller.getNotes();// get the notes of the appointment from the field
            LocalDate dateOfIssue = controller.getDateOfIssue(); // get the date of issue of appointment from the field
            LocalDate deadline = controller.getDeadline(); // get the deadline of appointment from the field

            Appointment appointment = getAppointment(title,notes, dateOfIssue, deadline); // creates a appointment
            // if the details specified were not proper it returns null

            if(appointment != null){// check whether all details were specified or not
                // all details were specified properly
                boolean isAdded = manager.addAppointment(appointment); // add the appointment to the list
                if(!isAdded){
                    // title already exists
                    showAlert("An appointment with title \"" + appointment.getTitle() + "\" already exists.",
                                        Alert.AlertType.ERROR);
                }else{
                    // appointment added successfully
                    // save the appointments now
                    manager.saveAppointments();
                    setUpPageContent();// set the content of the page
                }
            }else{
                // all details are not properly specified
                // so cannot add this new appointment
            }

        }else{
            // discarded by the user
        }
    }


    private Appointment getAppointment(String title, String notes, LocalDate dateOfIssue, LocalDate deadline){

        // validate the title
        if(title.trim().isEmpty()){
            showAlert("Please provide a suitable \"Title\" for  appointment.",
                            Alert.AlertType.WARNING);
            return null;
        }

        // validate the deadline
        if(deadline == null){
            showAlert("Please provide a suitable \"Deadline\" for  appointment.",
                                Alert.AlertType.WARNING);
            return null;
        }

        // validate the date of issue
        if(dateOfIssue == null){
            // if date of issue is not supplied
            // consider it to be today's date
            dateOfIssue = LocalDate.now();
        }

        // validate notes
        if(notes.trim().isEmpty()){
            // if no notes are provided
            // consider the title as the notes
            notes = title;
        }

        // now we have all the information
        // we can add the new appointment
        return  new Appointment(title,notes,deadline,dateOfIssue);
    }



    private void showAlert(String msg, Alert.AlertType type){
        // shows the alert for the user
        // based on the type and content text as msg
        Alert alert = new Alert(type); // creates an object of class Alert
        alert.setHeaderText(null); // set the header text of the alert to be null
        alert.setTitle("Appointment Manager-Information"); // set the title of the alert
        alert.setContentText(msg); // set the content text of the alert
        alert.showAndWait(); // show and wait for the user's resposne
        // NOTE: It is a modal alert
    }


    private void displayDetailsOfSelectedItem(){

        // displays the content of the selected appointment

        //get the selected item from the list
        Appointment selectedAppointment = listView.getSelectionModel().getSelectedItem();

        if(selectedAppointment != null){
            // some item was selected

            // Format the date in format DayOfWeek, Day Month Year
            String text = "Date of Issue : " + selectedAppointment.getDateOfIssue().format(
                                    DateTimeFormatter.ofPattern("E, d MMM YYYY"));
            dateOfIssueLabel.setText(text); // display the date of issue
            text = "Deadline : " + selectedAppointment.getDeadline().format(
                                    DateTimeFormatter.ofPattern("E, d MMM YYYY"));
            deadlineLabel.setText(text); // display the deadline
            notesLabel.setText("\t\t\t\tNotes"); // display the notes Label
            notesArea.setText(selectedAppointment.getNotes());  // print the notes in the text area
        }else{
            // no item is selected
            // no information to be displayed
            dateOfIssueLabel.setText("");
            deadlineLabel.setText("");
            notesLabel.setText("");
            notesArea.setText("");
        }
    }

    @FXML
    public void handleSelectedItem(){
        displayDetailsOfSelectedItem(); // display the content of the selected item
    }

    @FXML
    public void handleKeyPressedListView(KeyEvent e){
        // give a user-friendly feel
        // allow the user to use the keyboard keys instead of clicking the buttons

        KeyCode code = e.getCode(); // get the code of the key pressed by the user

        if(code.equals(KeyCode.UP) || code.equals(KeyCode.DOWN)){
            displayDetailsOfSelectedItem();
        }else if(code.equals(KeyCode.DELETE)){
            handleDeleteButton(); // delete the appointment
        }else if(code.equals(KeyCode.ENTER)){
            handleEditButton(); // edit the appointment
        }
    }


    // set the content of the application
    // that is to be displayed to the user
    private void setUpPageContent(){

        int selectedChoice = choiceBox.getSelectionModel().getSelectedIndex();
        // get the selected choice of the user

        ObservableList<Appointment> appointments = manager.getAllAppointments(); // get the list of appointments

        // sort the appointments by deadline
        FXCollections.sort(appointments, new Comparator<Appointment>() {
            @Override
            public int compare(Appointment o1, Appointment o2) {
                return o1.getDeadline().compareTo(o2.getDeadline());
            }
        });

        FilteredList<Appointment> items;
        String typeOfAppointments ;

        switch(selectedChoice){
            // take action according to the user's choice
            case 1:
                items = appointments.filtered(new Predicate<Appointment>() {
                    @Override
                    public boolean test(Appointment appointment) {
                        return appointment.getDeadline().compareTo(LocalDate.now()) < 0 ;
                    }
                });
                typeOfAppointments = items.isEmpty() ? "No Delayed Appointments" : "Delayed Appointments\t";
                break;

            case 2:
                items = appointments.filtered(new Predicate<Appointment>() {
                    @Override
                    public boolean test(Appointment appointment) {
                        return appointment.getDeadline().compareTo(LocalDate.now()) ==0 ;
                    }
                });
                typeOfAppointments = items.isEmpty() ? "No Today's Appointments" : "Today's Appointments\t";
                break;

            case 3:
                items = appointments.filtered(new Predicate<Appointment>() {
                    @Override
                    public boolean test(Appointment appointment) {
                        return appointment.getDeadline().compareTo(LocalDate.now()) >=0 ;
                    }
                });
                typeOfAppointments = items.isEmpty() ? "No Upcoming Appointments" : "Upcoming Appointments";
                break;

            default:
                items = appointments.filtered(new Predicate<Appointment>() {
                    @Override
                    public boolean test(Appointment appointment) {
                        return true;
                    }
                });
                typeOfAppointments = items.isEmpty() ? "No Appointments\t" : "All Appointments\t\t";
        }

        // set the items of the list
        listView.setItems(items);

        // refresh the list
        listView.refresh();

        // set the type of the appointment
        appointmentType.setText(typeOfAppointments);

        // select the first appointment if present
        if(listView.getItems().size() >0){
            listView.getSelectionModel().selectFirst();
        }
        // display the content of the selected item
        displayDetailsOfSelectedItem();
    }

    @FXML
    public void handleChoiceBox(){
        setUpPageContent(); // set the content of the page
    }

    @FXML
    public void handleDeleteButton(){

        // handle the event fired by the delete button

        //get the selected appointment from the list
        Appointment selectedAppointment = listView.getSelectionModel().getSelectedItem();

        if(selectedAppointment != null){
            // some appointment is selected

            // display a conformation aletr
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION); // conformation type alert
            alert.setHeaderText(null); // set the header text of the alert to be null
            alert.setTitle("Deleting Appointment"); // set the title of the alert
            alert.setContentText("Are you sure want to delete Appointment : \"" + selectedAppointment.getTitle()+
                                "\" ?"); // set the context of the alert
            Optional<ButtonType> result = alert.showAndWait(); // show the alert and wait for the user's resoponse

            if(result.isPresent() && result.get() == ButtonType.OK){
                // Ok was pressed
                // deletion conformed
                boolean isDeleted = manager.deleteAppointment(selectedAppointment); // delete the appointment
                if(isDeleted){
                    // appointment deleted
                    manager.saveAppointments(); // save the appointments
                   setUpPageContent(); // set the content of the page
                }else{
                    // could not delete the appointment
                    // because no such appointment exists
                    showAlert("Appointment \"" + selectedAppointment.getTitle() + "\" not found.",
                                    Alert.AlertType.INFORMATION);
                }
            }
        }else{
            // no appointment is selected
            showAlert("No Appointment Selected.\nPlease select an Appointment.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleSearchButton(){

        // handle the event fired by the search button

        String text = searchField.getText(); // get the text to be searched for

        boolean isFound = false; // assume result do not exists

        if(!text.trim().isEmpty()){
            // a valid text

            //get the list of appointments
            ObservableList<Appointment> appointments = manager.getAllAppointments();

            // iterate through the list of  appointments
            for(Appointment appointment : appointments){

                // get the title of the appointment under iteration
                String title = appointment.getTitle();

                // check whether this title contains the text to be searched
                if(title.contains(text)){
                    // text found
                    isFound = true; // text found

                    // make a message for the user
                    String msg = "Title: " + appointment.getTitle() + "\n" +
                            "Date Of Issue: " + appointment.getDateOfIssue().format(
                                    DateTimeFormatter.ofPattern("E, d MMM YYYY")) + "\n" +
                            "Deadline: " + appointment.getDeadline().format(
                                    DateTimeFormatter.ofPattern("E, d MMM YYYY")) + "\n";

                    // show the information of the founded appointment
                    showAlert(msg, Alert.AlertType.INFORMATION);

                    // ask user to search next or stop
                    Dialog<ButtonType> dialog = new Dialog<>(); // create a dialog
                    dialog.setTitle("Search Next"); // set the title of the dialog
                    dialog.getDialogPane().setContentText("Search for next occurrence ?"); // set teh content of the dialog
                    dialog.getDialogPane().setHeaderText(null); // set the header text of the dialog to null
                    // add the button to the dialog
                    dialog.getDialogPane().getButtonTypes().addAll(ButtonType.NEXT, ButtonType.CANCEL);

                    // show the dialog and wait for the user's response
                    Optional<ButtonType> result = dialog.showAndWait();

                    if(result.isPresent() && result.get() == ButtonType.NEXT){
                        // user wants to search for the next appointment
                        continue;
                    }else{
                        // do no t search further
                        return;
                    }
                }else{
                    // data not match
                    // move on to next element
                    continue;
                }
            }
            // data not exist
            if(isFound){
                // display a message that no more data found, if user want to search for more appointments and it
                // do not exists
                showAlert("No more record found for \" " + text + "\".", Alert.AlertType.INFORMATION);
            }else{
                // display a message that record not found
                showAlert("No record found for \" " + text + "\".", Alert.AlertType.INFORMATION);
            }
        }else{
            // no text is provided for searching
            showAlert("Please provide a \"Title\" to be searched for.", Alert.AlertType.WARNING);
        }
    }

    @FXML
    public void handleSearchField(){
        // give a user-friendly feel to the application
        // allow user to press enter instead of clicking the search button for searching
        handleSearchButton(); // same work as for the search button
    }


    @FXML
    public void handleEditButton(){
        // handle the event fired by the edit button


        // get the selected item from the list
        Appointment selectedAppointment = listView.getSelectionModel().getSelectedItem();


        if(selectedAppointment != null){
            // some appointment is selected
            Dialog<ButtonType> dialog = new Dialog<>();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("newAppointment.fxml"));
            try{
                dialog.getDialogPane().setContent(loader.load());
            }catch(IOException e){
                System.out.println("Couldn't load the newAppointment.fxml file");
                return;
            }
            // file loaded successfully
            dialog.setTitle("New Details");
            dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
            Optional<ButtonType> result = dialog.showAndWait();

            if( result.isPresent() && result.get() == ButtonType.OK){

                // OK was pressed
                //  get the details from the fields
                NewAppointmentController controller = loader.getController();
                String title = controller.getTitle();
                String notes = controller.getNotes();
                LocalDate dateOfIssue = controller.getDateOfIssue();
                LocalDate deadline = controller.getDeadline();

                Appointment newAppointment= getAppointment(title,notes, dateOfIssue, deadline);

                if(newAppointment != null){// check whether all details are specified or not
                    // all details were specified properly
                    manager.deleteAppointment(selectedAppointment); // delete the selected appointment
                    boolean isAdded = manager.addAppointment(newAppointment); // add the edited appointment
                    if(!isAdded){
                        // title already exists
                        showAlert("An appointment with title \"" + newAppointment.getTitle() + "\" already exists.",
                                Alert.AlertType.ERROR);
                        manager.addAppointment(selectedAppointment); // re add the same appointment
                        manager.saveAppointments();
                        listView.getSelectionModel().select(selectedAppointment);
                        displayDetailsOfSelectedItem();
                    }else{
                        // edited appointment added successfully
                        // save the appointments now
                        manager.saveAppointments();
                        listView.getSelectionModel().select(newAppointment);
                        displayDetailsOfSelectedItem();
                    }
                }else{
                    // details are not properly specified
                    // cannot edit the appointment
                }


            }else{
                // discarded by the user
            }


        }else{
            // no appointment is selected
            showAlert("No Appointment Selected.\nPlease select an Appointment.", Alert.AlertType.ERROR);
        }
    }

}
