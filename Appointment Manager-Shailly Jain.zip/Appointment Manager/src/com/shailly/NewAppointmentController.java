package com.shailly;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.time.LocalDate;

public class NewAppointmentController {

    @FXML
    public TextField titleTextField;
    @FXML
    public DatePicker dateOfIssuePicker;
    @FXML
    public DatePicker deadlinePicker;
    @FXML
    public TextArea notesTextArea;

    @FXML
    public Label titleLabel,notesLabel,dateOfIssueLabel,deadlineLabel;

    @FXML
    public void initialize(){
        try{
            notesLabel.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("notesLabel.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon notesLabel.png");
        }
        try{
            dateOfIssueLabel.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("dateOfIssueLabel.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon dateOfIssueLabel.png");
        }

        try{
            deadlineLabel.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("deadlineLabel.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon deadlineLabel.png");
        }
        try{
            titleLabel.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("titleLabel.png"))));
        }catch(Exception e){
            System.out.println("Could not load the icon titleLabel.png");
        }
    }

    public String getTitle(){
        return titleTextField.getText();
    }

    public String getNotes(){
        return notesTextArea.getText();
    }
    public LocalDate getDateOfIssue(){
        return dateOfIssuePicker.getValue();
    }
    public LocalDate getDeadline(){
        return deadlinePicker.getValue();
    }

}
